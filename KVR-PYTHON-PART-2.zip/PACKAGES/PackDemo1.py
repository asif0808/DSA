import sys
sys.path.append("C:\\Users\\KVR\\PycharmProjects\\6PMModules")
import Welcome as w
w.greet("Rossum")
w.greet("TR")