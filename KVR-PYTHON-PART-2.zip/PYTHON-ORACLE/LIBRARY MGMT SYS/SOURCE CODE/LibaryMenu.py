#LibrayMenu.py<--------File Name and Module Name
def menu():
    print("*"*50)
    print("\tLibrary Management System")
    print("*" * 50)
    print("\t\t1.Add a New Book")
    print("\t\t2.Delete a Book")
    print("\t\t3.Update Book Deatils")
    print("\t\t4.View Book Details")
    print("\t\t5.View All Book Deatils")
    print("\t\t6.Exit")
    print("*" * 50)

