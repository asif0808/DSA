#Program for Demonstrating Relational Operators
#RelationalOperators.py
a=int(input("Enter value of a:"))
b=int(input("Enter value of b:"))
print("="*50)
print("\tResult of Relational Operators")
print("="*50)
print("\t\t{} > {} = {}".format(a,b,a>b))
print("\t\t{} < {} = {}".format(a,b,a<b))
print("\t\t{}=={} = {}".format(a,b,a==b))
print("\t\t{}!={} = {}".format(a,b,a!=b))
print("\t\t{}>={} = {}".format(a,b,a>=b))
print("\t\t{}<={} = {}".format(a,b,a<=b))
print("="*50)
