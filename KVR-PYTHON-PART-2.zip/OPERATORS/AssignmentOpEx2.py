#program for Swapping any Two Values
#AssignmentOpEx2.py
a,b=input("Enter Value of a:"),input("Enter Value of b:")
print("-"*50)
print("Original value of a:{}".format(a))
print("Original value of b:{}".format(b))
print("-"*50)
#Swapping Logic
k=a  # Single Line Assigment
a=b
b=k
print("Swapped value of a:{}".format(a))
print("Swapped value of b:{}".format(b))
print("-"*50)
