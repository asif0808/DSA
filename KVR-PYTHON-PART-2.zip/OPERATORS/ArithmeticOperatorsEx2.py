#ArithmeticOperatorsEx2.py
n=float(input("Enter val of n:"))
res=n**(1/2)  # OR res=n**0.5
print("sqrt({})={}".format(n,res))