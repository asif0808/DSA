#Student.py<---File Name and Module Name
class Student:
    def readstudata(self):
        print('-'*50)
        self.sno = int(input("\tEnter Student Number:"))
        self.sname = input("\tEnter Student Name:")