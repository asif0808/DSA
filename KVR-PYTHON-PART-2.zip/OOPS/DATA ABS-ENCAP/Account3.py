#Program for Demonstrating Data Encapsulation
#Account3.py<----File name and Module name
class Account:
    def __getaccdet(self):
        self.acno=999
        self.cname="Rossum"
        self.bal=5.6
        self.pin=7867
        self.bname="SBI"
