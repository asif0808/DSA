#Program for Demonstrating Data Abstraction
#Others2.py
from Account2 import Account
ac=Account()
ac.getaccdet()
#print("Account Number=",ac.acno)
print("Account Holder Name=",ac.cname)
#print("Account Balance=",ac.bal)
#print("Account PIN=",ac.pin)
print("Account Branch Name=",ac.bname)