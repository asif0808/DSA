#Program for Demonstrating Data Encapsulation
#Account2.py<----File name and Module name
class Account:
    def getaccdet(self):
        self.__acno=999
        self.cname="Rossum"
        self.__bal=5.6
        self.__pin=7867
        self.bname="SBI"
