#Program for Demonstrating Data Abstraction
#Others4.py
from Account4 import Account
ac=Account()
ac.______init__()
print("Account Number=",ac.acno)
print("Account Holder Name=",ac.cname)
print("Account Balance=",ac.bal)
print("Account PIN=",ac.pin)
print("Account Branch Name=",ac.bname)