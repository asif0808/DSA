#Program for Demonstrating Data Encapsulation
#Account1.py<----File name and Module name
class Account:
    def __init__(self):
        self.__acno=999
        self.cname="Rossum"
        self.__bal=5.6
        self.__pin=7867
        self.bname="SBI"
