#Program for Demonstrating Data Abstraction
#Others3.py
from Account3 import Account
ac=Account()
#ac.getaccdet()
#print("Account Number=",ac.acno)
#print("Account Holder Name=",ac.cname)
#print("Account Balance=",ac.bal)
#print("Account PIN=",ac.pin)
#print("Account Branch Name=",ac.bname)