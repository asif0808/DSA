#Program for Demonstrating break keyword
#BreakEx4.py
lst=[10,20,30,40,50,60,70,80,90]
for value in lst:
    if(value==50):
        break
    print(value,end="==>")
