#FromImportSyntax-2.py
from icici import bname as bn ,addr as ad ,simpleint as si
from Aop import sumop as ap,subop as sp, mulop as mp
print("Bank Name: ",bn)
print("Bank Address: ",ad)
si()
print("------------------------")
ap(2,3)
sp(10,20)
mp(3,4)