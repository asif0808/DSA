#SE3.py
import icici
print("Bank Name:",icici.bname)
print("Bank Address:",icici.addr)
icici.simpleint()