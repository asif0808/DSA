#FromImportSyntax-3.py
from icici import *
from Aop import *
from MathsInfo import *
print("Bank Name: ",bname)
print("Bank Address: ",addr)
simpleint()
print("----------------------")
sumop(10,20)
mulop(4,5)
print("-------------------------")
print("PI=",PI)
print("E=",E)