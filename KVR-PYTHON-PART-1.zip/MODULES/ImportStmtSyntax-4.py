#ImportStmtSyntax-4.py
import icici as k,Aop as v,MathsInfo as r
print("Bank Name:",k.bname)
print("Bank Address:",k.addr)
k.simpleint()
print("---------------------------")
v.subop(10,20)
print("Val of PI=",r.PI)