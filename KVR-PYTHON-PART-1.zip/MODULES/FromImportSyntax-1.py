#FromImportSyntax-1.py
from icici import bname,addr, simpleint
print("Bank Name: ",bname)
print("Bank Address: ",addr)
simpleint()