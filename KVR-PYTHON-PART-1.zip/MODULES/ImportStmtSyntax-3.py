#ImportStmtSyntax-3.py
import icici as ic
import Aop as a
import MathsInfo as m
print("Bank Name:",ic.bname)
print("Bank Address:",ic.addr)
ic.simpleint()
print("---------------------------")
a.sumop(10,20)
print("Val of PI=",m.PI)