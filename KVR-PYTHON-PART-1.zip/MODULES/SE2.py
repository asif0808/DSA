#SE2.py
import Aop
Aop.sumop(10,20) # function call
Aop.subop(5,6) # Function call
Aop.mulop(10,2) # function call

