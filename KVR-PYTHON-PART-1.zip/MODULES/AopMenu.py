#AopMenu.py<---File Name and Module Name
def AopMenu():
    print("="*50)
    print("\tArithMetic Operations")
    print("=" * 50)
    print("\t\t1.Addition")
    print("\t\t2.Substraction")
    print("\t\t3.Multiplication")
    print("\t\t4.Division")
    print("\t\t5.Modulo Division")
    print("\t\t6.Exponentiation")
    print("\t\t7.Exit")
    print("=" * 50)
