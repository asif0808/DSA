#Shares.py<--File Name and Module Name--updater
def sharesinfo():
    d={"INFO":1000,"FN":1000,"PM":1020,"AB":2000,"KS":200}
    return d
