#ImportStmtSyntax-1.py
import icici
import Aop
import MathsInfo
print("Bank Name:",icici.bname)
print("Bank Address:",icici.addr)
icici.simpleint()
print("---------------------------")
Aop.sumop(10,20)
print("Val of PI=",MathsInfo.PI)