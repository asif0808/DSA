#ImportStmtSyntax-2.py
import icici,Aop,MathsInfo
print("Bank Name:",icici.bname)
print("Bank Address:",icici.addr)
icici.simpleint()
print("---------------------------")
Aop.subop(10,20)
print("Val of PI=",MathsInfo.PI)