#SE1.py--
import MathsInfo
print(MathsInfo.PI)
print(MathsInfo.E)