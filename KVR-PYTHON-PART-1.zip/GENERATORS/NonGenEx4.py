#Program for Demonstrating Generator
#NonGenEx4.py
def  getcourses():
	return "PYTHON"
	return  "HTML"
	return "C"
	return "C++"


#Main Program
nitcrs=getcourses()
print(nitcrs,type(nitcrs)) # PYTHON <class 'str'>