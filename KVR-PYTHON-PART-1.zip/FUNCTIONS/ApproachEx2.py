#Define a function for Adding of Two Numbers
#ApproachEx2.py
#Input:  Taken Inside of Function Body
#Process: Done in Function Body
#Output: Displayed in Function Body
def sumop():
    #take input
    a=float(input("Enter First Value:"))
    b=float(input("Enter Second Value:"))
    #Process
    c=a+b
    #Display the Result
    print("Sum({},{})={}".format(a,b,c))
#Main Program
sumop() #Function Call