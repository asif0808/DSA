#EmpPickUnPickMenu.py<---File Name and Module Name
def menu():
	print("*"*50)
	print("\tEmployee Operations")
	print("*"*50)
	print("\t1.Save Emp Data")
	print("\t2.Record Emps Data")
	print("\t3.Exit")
	print("*"*50)

