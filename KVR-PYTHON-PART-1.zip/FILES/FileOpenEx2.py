#This Program demonstrates how to open the File
#FileOpenEx2.py
fp=open("kvr1.data","w")
print("Type of fp=",type(fp))
print("File created and opened in Write Mode")