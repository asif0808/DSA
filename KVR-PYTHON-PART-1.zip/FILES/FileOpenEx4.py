#This Program demonstrates how to open the File
#FileOpenEx4.py
with open("kvr2.py","w") as fp:
     print("Type of fp=",type(fp))
     print("File Opened in Write mode successfully")
