#Programmer-Defined exception sub class works like ZeroDivisionError
#Hyd.py<---File Name and Module
class DivsionByZeroError(Exception):pass

#Phase-1 : We develop Programmer-Defined Exceptions.