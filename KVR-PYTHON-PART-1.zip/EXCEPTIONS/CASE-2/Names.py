#Names.py
class InvalidNameError(BaseException):pass
class ZeroLengthNameError(Exception):pass
