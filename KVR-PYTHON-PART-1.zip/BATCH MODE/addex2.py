#Program for adding of Two Number
a=10
b=20
c=a+b
print("*"*50)
print("Val of a=",a)
print("Val of b=",b)
print("sum=",c)
print("*"*50)
