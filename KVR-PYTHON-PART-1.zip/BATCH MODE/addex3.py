#Program for adding Two Numbers
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
c=a+b
print("="*50)
print("Val of a={}".format(a))
print("Val of b={}".format(b))
print("sum({},{})={}".format(a,b,c))
print("="*50)
