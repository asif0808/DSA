#Moviee.py
tkt=input("Do u have ticket(yes/no):") # 123
if(tkt.lower()=="yes"):
    print("Enter into theater")
    print("watch the Moviee")
    print("Eat pop corn!!!")
if tkt.lower() not in ["yes","no"]:
    print("Plz Learn Typing")

print("Goto Home and Read Python Notes")