#Program for Obtaining Reverse of a Given Value--by using extended Slicing
#ValueReverseEx1.py--Logic-1  (Int data and str data)
value=input("Enter Any Value:")
reversedvalue=value[::-1] # Extended Slicing Tech
print("Original value:",value)
print('Reversed Value:',reversedvalue)