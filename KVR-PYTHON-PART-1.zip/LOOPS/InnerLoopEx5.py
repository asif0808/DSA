#InnerLoopEx5.py
for i in range(1,4):
    for j in range(1,4):
        for k in range(1,4):
            print("i:{} j:{} k:{}".format(i,j,k))
        print("--------------------------")