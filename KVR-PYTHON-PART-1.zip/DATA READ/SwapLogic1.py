#Program for Swapping of Two Values
#SwapLogic1.py
a=input("Enter Val of a:")
b=input("Enter Val of b:")
print("="*50)
print("Orignal value of a:{}".format(a))
print("Orignal value of b:{}".format(b))
print("-"*50)
#Swapping Logic
k=a # here k is called Temporary variable
a=b
b=k
print("Swapped value of a:{}".format(a))
print("Swapped value of b:{}".format(b))
print("="*50)
