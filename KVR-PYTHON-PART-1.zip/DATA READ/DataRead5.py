#Program for Multipying two Numerial values
#DataRead6.py
x=float(input("Enter First Value:"))
y=float(input('Enter Second Value:'))
print("Mul({},{})={}".format(x,y,x*y))
