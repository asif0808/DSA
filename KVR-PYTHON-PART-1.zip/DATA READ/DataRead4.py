#Program for Multipying two Numerial values
#DataRead4.py
x=float(input("Enter First Value:"))
y=float(input('Enter Second Value'))
#Multiply
z=x*y
print("Mul({},{})={}".format(x,y,z))
