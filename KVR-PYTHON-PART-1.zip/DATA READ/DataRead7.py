#Program for Multipying two Numerial values
#DataRead7.py
print("Mul={}".format(float(input("Enter First Value:"))*float(input('Enter Second Value:'))))
print("-------------------OR-----------------------------")
print("Mul=%0.2f" %(float(input("Enter First Value:"))*float(input('Enter Second Value:'))))
