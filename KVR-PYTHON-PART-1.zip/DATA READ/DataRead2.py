#DataRead2.py
a=input("Enter Value:")
print(a,type(a))