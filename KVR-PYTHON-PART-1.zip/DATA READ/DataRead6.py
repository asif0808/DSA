#Program for Multipying two Numerial values
#DataRead6.py
print("Enter Two Values")
x=float(input())
y=float(input())
print("Mul({},{})={}".format(x,y,x*y))
print("--------------OR-------------------")
print("Mul(%0.2f,%0.2f)=%0.2f" %(x,y,x*y))
print("--------------OR-------------------")
print("Mul({},{})={}".format(x,y,round(x*y,2)))