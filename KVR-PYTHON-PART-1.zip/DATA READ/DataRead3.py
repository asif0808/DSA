#Program for Multipying two Numerial values
#DataRead3.py
a=input("Enter First Value:")
b=input("Enter Second Value:")
#here a,b are of type str and convert them into float
x=float(a)
y=float(b)
#Multiply
z=x*y
print("Mul({},{})={}".format(x,y,z))
