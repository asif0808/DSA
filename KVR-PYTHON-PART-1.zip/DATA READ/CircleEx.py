#program for cal area and Perimter of Circle
#CircleEx.py
rad=float(input("Enter Radius:"))
ac=3.14*rad*rad
pc=2*3.14*rad
print("*"*50)
print("Radius={}".format(rad))
print("Area of Circle={}".format(ac))
print("Perimter if Circle={}".format(pc))
print("*"*50)
