#DataRead1.py--input() and print()
print("Enter Value:")
a=input()
print(a,type(a))